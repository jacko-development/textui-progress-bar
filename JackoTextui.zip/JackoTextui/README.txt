hello voici mon textui progress-bar

les export sont

pour les progress-bar

exports['JackoTextui']:ProgressBar('TEXT AFFICHER', 'COLORS 1', TIME en seconde, 'COLORS 2', true)

pour les textui

-afficher
exports['JackoTextui']:Textui('TOUCHE', 'LABEL', 'COLOR', true)

-cacher
exports['JackoTextui']:HideTextui(true)

les color sont sur se format "#0edae9c2"

jespere que cette ressource vous plaira !


