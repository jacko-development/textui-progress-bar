
function Textui(touche, message, color)
    SendNUIMessage({
      visibility = "visible",
      touche = touche,
      message = message,
      couleur = color
    })
end

function HideTextui()
      SendNUIMessage({
        visibility = "hidden"
      })
end

function ProgressBar(message, color, time, colorbarre)
  SendNUIMessage({
    visibility_ProgressBar = "visible",
    couleur = color,
    time = time,
    messages = message,
    colorbarre = colorbarre
  })
  Wait(time*1000)
end