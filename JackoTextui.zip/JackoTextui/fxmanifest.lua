fx_version 'cerulean'
game 'gta5'

description 'Textui by jacko dev'
version '1.0'
lua54 'yes'
ui_page 'html/index.html'

shared_script {"@es_extended/imports.lua"}

files {
    'html/index.html',
    'html/js/index.js',
    'html/styles/style.css'
}

client_scripts({
    'client/*.lua'
});

export 'Textui'
export 'HideTextui'
export 'ProgressBar'