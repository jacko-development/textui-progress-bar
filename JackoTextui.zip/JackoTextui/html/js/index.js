window.addEventListener('message', function(event) {
    const info = event.data
    const root = document.documentElement;
    document.querySelector(".textui_contour").style.visibility = info.visibility;
    document.querySelector(".textui_touche").innerHTML = info.touche; 
    document.querySelector(".textui_message").innerHTML = info.message;
    root.style.setProperty('--couleur', info.couleur);
    document.querySelector(".progress_contour").style.visibility = info.visibility_ProgressBar; 
    if (info.visibility_ProgressBar === 'visible') {
        const textuiInter = document.querySelector(".textui_inter");
        console.log(info.time*1000);
        root.style.setProperty('--time', info.time + "s");
        root.style.setProperty('--couleur', info.couleur);
        root.style.setProperty('--couleur-barre', info.colorbarre);
        document.querySelector(".progress_message").innerHTML = info.messages;
        textuiInter.style.animationPlayState = "running";
        setTimeout(delete_progress, info.time*1000);
    }
});

function delete_progress() {
    document.querySelector(".progress_contour").style.visibility = "hidden";
    const textuiInter = document.querySelector(".textui_inter");
    document.querySelector(".progress_message").innerHTML = null;
    textuiInter.style.animation = 'none';
    void textuiInter.offsetWidth;
    textuiInter.style.animation = null;
}